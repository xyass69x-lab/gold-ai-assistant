import os
from datetime import datetime, timezone
from typing import Optional

import requests
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()
app = FastAPI(title="Gold AI Assistant", version="0.1.0")
LATEST = {"status": "waiting", "message": "لا توجد إشارات بعد", "updated": None}
HISTORY = []

class Signal(BaseModel):
    symbol: str = Field(default="XAUUSD")
    side: str
    entry: float
    stop_loss: float
    take_profit: float
    timeframe: str = "5m"
    reason: str = "إشارة من استراتيجية TradingView"
    confidence: Optional[int] = None

def validate_signal(s: Signal):
    if s.symbol.upper().replace("/", "") not in ("XAUUSD", "GOLD"):
        raise HTTPException(400, "هذا المشروع مخصص للذهب XAU/USD فقط")
    side = s.side.upper()
    if side not in ("BUY", "SELL"):
        raise HTTPException(400, "side must be BUY or SELL")
    if side == "BUY" and not (s.stop_loss < s.entry < s.take_profit):
        raise HTTPException(400, "ترتيب أسعار الشراء غير صحيح")
    if side == "SELL" and not (s.take_profit < s.entry < s.stop_loss):
        raise HTTPException(400, "ترتيب أسعار البيع غير صحيح")
    risk = abs(s.entry - s.stop_loss)
    reward = abs(s.take_profit - s.entry)
    rr = reward / risk if risk else 0
    if rr < 2:
        raise HTTPException(400, "تم رفض الإشارة: العائد إلى المخاطرة أقل من 1:2")
    return rr

def telegram_send(text: str):
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id:
        return False, "بيانات تلجرام غير مكتملة"
    try:
        response = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": text},
            timeout=8,
        )
        response.raise_for_status()
        return True, "sent"
    except requests.RequestException:
        return False, "تعذر إرسال رسالة تلجرام"

@app.get("/", response_class=HTMLResponse)
def dashboard():
    path = os.path.join(os.path.dirname(__file__), "dashboard.html")
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

@app.get("/api/status")
def status():
    return {"latest": LATEST, "history": HISTORY[-10:], "mode": "signals_only"}

@app.post("/webhook/{token}")
async def tradingview_webhook(token: str, request: Request):
    expected = os.getenv("WEBHOOK_TOKEN", "")
    if not expected or token != expected:
        raise HTTPException(401, "Unauthorized")
    try:
        payload = await request.json()
        signal = Signal(**payload)
    except Exception:
        raise HTTPException(400, "JSON غير صالح أو حقول الإشارة ناقصة")

    rr = validate_signal(signal)
    now = datetime.now(timezone.utc).isoformat()
    side = signal.side.upper()
    message = (
        f"🟡 GOLD AI ASSISTANT\\n"
        f"إشارة {side} — {signal.symbol}\\n"
        f"الإطار: {signal.timeframe}\\n"
        f"الدخول: {signal.entry}\\n"
        f"وقف الخسارة: {signal.stop_loss}\\n"
        f"الهدف: {signal.take_profit}\\n"
        f"العائد/المخاطرة: 1:{rr:.2f}\\n"
        f"السبب: {signal.reason}\\n\\n"
        "⚠️ تنبيه تحليلي فقط — راجع السعر والسبريد وحجم العقد في XTB قبل أي تنفيذ. لا يوجد ضمان للربح."
    )
    sent, note = telegram_send(message)
    item = {
        "symbol": signal.symbol, "side": side, "entry": signal.entry,
        "stop_loss": signal.stop_loss, "take_profit": signal.take_profit,
        "timeframe": signal.timeframe, "reason": signal.reason,
        "rr": round(rr, 2), "updated": now, "telegram": sent,
    }
    HISTORY.append(item)
    LATEST.clear()
    LATEST.update({"status": "signal", "message": f"{side} XAU/USD", "updated": now, **item})
    return JSONResponse({"accepted": True, "telegram_sent": sent, "telegram_status": note, "signal": item})

@app.get("/health")
def health():
    return {"ok": True, "service": "Gold AI Assistant", "version": "0.1.0"}
